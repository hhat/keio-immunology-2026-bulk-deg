Bulk RNA-seq DEG course data
Created for a 90-minute microbiology/immunology practical class.

Contents:
- sample_meta.tsv: de-identified HC/SLE sample labels used in this notebook
- celltype_info.tsv: selected immune cell types
- IFNgenes100.txt: interferon-related gene set used for a mini enrichment exercise
- count/*_count.tsv: raw count matrices for selected sorted immune cell types

Samples:
- HC: 20
- SLE: 20

Cell types:
pDC, CL_Mono, mDC, Th1, Th17, Plasmablast, NK

Note:
The student-facing sample IDs are relabeled to HC01-HC20 and SLE01-SLE20.
